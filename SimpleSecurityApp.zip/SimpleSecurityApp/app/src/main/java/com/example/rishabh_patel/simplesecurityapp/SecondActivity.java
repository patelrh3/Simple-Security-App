package com.example.rishabh_patel.simplesecurityapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;


public class SecondActivity extends AppCompatActivity {


    private Button bOne;
    private Button bTwo;
    private Button bThree;
    private Button bFour;
    private Button sButton;

    String passcode = "";
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        sButton = (Button)findViewById(R.id.submitButton);

        bOne = (Button)findViewById(R.id.button1);
        bTwo = (Button)findViewById(R.id.button2);
        bThree = (Button)findViewById(R.id.button3);
        bFour = (Button)findViewById(R.id.button4);

        bOne.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                passcode += "1";
            }
        });

        bTwo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                passcode += "2";
            }
        });
        bThree.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                passcode += "3";
            }
        });
        bFour.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                passcode += "4";
            }
        });


        sButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (passcode.equals("1234"))
                {
                    Intent result = new Intent();
                    setResult(RESULT_OK, result);
                    finish();
                }
                else
                {
                    Intent intent = new Intent (SecondActivity.this, MainActivity.class);
                    startActivity(intent);
                }

            }
        });
    }

}
